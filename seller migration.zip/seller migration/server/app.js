const express = require('express');
const mongoose = require('mongoose');
const flipkartRoutes = require('./routes/flipkartRoutes');
const cors = require('cors');


const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/flipkartdb").then(() => {
    console.log("Connected to MongoDB");
}).catch((error) => {
    console.log("Error: ", error.message);
});

//routes
app.use('/flipkart', flipkartRoutes);




app.listen(3001, () => {
    console.log("Server is running on port 3001");
});


